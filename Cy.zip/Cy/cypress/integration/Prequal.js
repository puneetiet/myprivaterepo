describe('Pre-qual', function () {
    it('Homeloancollection', function () {
        //Visiting Pre qual URL
         cy.visit("https://applysit.bendigobank.com.au/bendigoapply/servlet/SmartForm.html?formCode=home-loan-pq")
         //Clicking on start 
         cy.contains('Start').click()
         //Clicking on Yes
         cy.contains('Yes').click()
         //Clicking on two of us
         cy.contains('Two of us').click()
         //Clicking on buy your next home to click in
         cy.get('.id-nextHome > .touch-input').click()
         //Clicking on unsure
         cy.contains('Unsure').click()
         //Entering value on how much you want to spend in property
         cy.get('#application_GettingStarted_PropertyValue').type('400000')
         //Entering value on your contribution
         cy.get('#application_GettingStarted_Contribution').type('200000')
         //Entering value of suburb where you want to purchase house
         cy.get('#application_GettingStarted_SuburbLookup_Search').type('Bendigo 3550 VIC',{delay : 200}) 
         cy.get('.id-referenceCode > :nth-child(2) > .text-display').click()        
         //Clicking on Interest Only
         cy.contains('Interest Only').click()
         //Clicking on Fortnightly
         cy.contains('Fortnightly').click()
         //Clicking on basic home loan rate
         cy.get('fieldset.ng-scope > :nth-child(3) > .touch-input').click()
         //assert that per fortnight statement is shown
         //cy.get('[style="font-size:24px"] > span > .ng-binding').should('include','per fortnight')
         //Click on continue
         cy.get('.id-wizard_continue > .btn > .wdg-button-label').click()
         cy.wait(5000)
         //Click on No
         cy.get(':nth-child(3) > .touch-input').click()

         //Click Yes if living in same dwelling
         cy.get(':nth-child(1) > .av-radio-button-group > fieldset > :nth-child(2) > .touch-input').click()

         //Click Yes for relationship as marriage
         cy.get('.av-optional > :nth-child(2) > .av-radio-button-group > fieldset > :nth-child(2) > .touch-input').click()

         //Inform how many dependents you have
         //Displaying 1 dependent
         cy.contains('1').click()

         //Enter taxable income
         cy.get('#application_Finances_Applicant1_ApplicantFinance_PrimaryIncomeItem_Amount').type('5000',{delay :100})

         //Select frequency
         cy.get('#application_Finances_Applicant1_ApplicantFinance_PrimaryIncomeItem_Frequency')
            .select("Weekly")

         //Saying extra income
         cy.get(':nth-child(4) > .av-radio-button-group > fieldset > :nth-child(2) > .touch-input').click()
         
         //Selecting new extra income type
         cy.get('#application_Finances_Applicant1_ApplicantFinance_OtherIncomes_IncomeItem_IncomeType-i0')
           .select("Bonus")
         
         //giving income amount
         cy.get('#application_Finances_Applicant1_ApplicantFinance_OtherIncomes_IncomeItem_Amount-i0').type("5000")

        //Giving income of customer 2
        cy.get('#application_Finances_Applicant2_ApplicantFinance_PrimaryIncomeItem_Amount').type('200',{delay :100})

        //Select frequency
        cy.get('#application_Finances_Applicant2_ApplicantFinance_PrimaryIncomeItem_Frequency')
        .select("Weekly")

        //Clicking yes for additional income
        cy.get(':nth-child(3) > .animate-height-if > :nth-child(4) > .av-radio-button-group > fieldset > :nth-child(2) > .touch-input').click()



         


            
            

         



    })

    })





